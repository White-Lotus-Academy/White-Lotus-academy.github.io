# Infinity-Stella  
![image](https://github.com/egliette/Infinity-Stella/assets/77763935/74e27b75-7387-4a91-91d2-9aa92cd0fa60)

This is endless game. Continuously upgrade and defeat the enemies!  
Use arrows to move, z/x to attack/defend.   
Play at here: https://egliette.github.io/Infinity-Stella/
